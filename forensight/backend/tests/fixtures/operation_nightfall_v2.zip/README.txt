FORENSIGHT — OPERATION NIGHTFALL TEST DATASET
Synthetic data only; all entities/events are fictional.

Case ID: FS-2026-NTF-002
Case: Operation Nightfall
Incident: North Dock Warehouse
Incident window: 14 Oct 2026, 20:00–20:45 IST
Geofence: 250 m around 28.7124, 77.1187

FILES
messages.csv              157 records
calls.csv                  75 records
gps.csv                   104 records
browser_artifacts.json     23 records
app_artifacts.json         23 records
case_metadata.json
evidence_manifest.json
README.txt

TEST:
- Upload as ZIP using Import Evidence
- Create a NEW case
- Validate and analyze
- Check evidence counts, timeline, connections, geo analysis,
  correlations, anomalies, integrity and Copilot
- Test offline after ingestion

Expected signals:
- Warehouse searches before movement
- GPS approach and geofence entry around 20:06
- "I’m here." at 20:11
- Rook calls around the incident
- FileShare activity during dwell
- History-deletion searches after departure
